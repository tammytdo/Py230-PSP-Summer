from django.urls import path
from django.conf.urls import url

from .views import detail_view, list_view, Login, Logout

from . import views


urlpatterns = [
    path('', list_view, name="blog_index"),
    path('posts/<int:post_id>/', detail_view, name="blog_detail"),

    url(r'^login/$', views.Login),
    url(r'^login/$', views.Logout),
    url(r'^home/$', views.Home),
    url(r'^blog/$', views.Blog),

]
